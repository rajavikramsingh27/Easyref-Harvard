//
//  ProjectReferencesTableViewController.m
//  ReferencingApp
//
//  Created by Radu Mihaiu on 19/08/2014.
//  Copyright (c) 2014 SquaredDimesions. All rights reserved.
//

#import "ProjectReferencesTableViewController.h"
#import "EasyReferencingViewController.h"
#import "CreateReferenceTableViewController.h"
#import "IndexViewController.h"
#import <ActionSheetPicker-3.0/ActionSheetPicker.h>
#import "NSAttributedString+Ashton.h"

#define UIColorFromRGB(rgbValue) [UIColor \
colorWithRed:((float)((rgbValue & 0xFF0000) >> 16))/255.0 \
green:((float)((rgbValue & 0xFF00) >> 8))/255.0 \
blue:((float)(rgbValue & 0xFF))/255.0 alpha:1.0]


@interface ProjectReferencesTableViewController ()

@end

@implementation ProjectReferencesTableViewController

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self.tableView setContentInset:UIEdgeInsetsMake(-1, 0, 0, 0)];

    refArray =  [[_currentProject.references allObjects] sortedArrayUsingComparator:^NSComparisonResult(Reference *p1, Reference *p2){
        
        return [[[p1 getReferenceString] string] compare:[[p2 getReferenceString] string] options:NSCaseInsensitiveSearch range:NSMakeRange(0, 1)];
        
    }];

    
    referenceTypeArray = [ReferencingApp sharedInstance].referenceTypeArray;
    
    
    
    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
    
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
    
    
}



-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    [ReferencingApp sharedInstance].delegate = self;
    
    [[IndexViewController sharedIndexVC] hideTopMenu];
    
    refArray =  [[_currentProject.references allObjects] sortedArrayUsingComparator:^NSComparisonResult(Reference *p1, Reference *p2){
        
        return [[[p1 getReferenceString] string] compare:[[p2 getReferenceString] string] options:NSCaseInsensitiveSearch range:NSMakeRange(0, 1)];
        
    }];

    [self.tableView reloadData];
    
    
    
    self.navigationController.navigationBar.barTintColor = [UIColor colorWithRed:52.0f/255.0f green:152.0f/255.0f blue:219.0f/255.0f alpha:0.70f];
    self.navigationController.navigationBar.backgroundColor = [UIColor colorWithRed:52.0f/255.0f green:152.0f/255.0f blue:219.0f/255.0f alpha:0.50f];

}

-(void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void) mailComposeController:(MFMailComposeViewController *)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError *)error
{
    switch (result)
    {
        case MFMailComposeResultCancelled:
            NSLog(@"Mail cancelled");
            break;
        case MFMailComposeResultSaved:
            NSLog(@"Mail saved");
            break;
        case MFMailComposeResultSent:
            NSLog(@"Mail sent");
            break;
        case MFMailComposeResultFailed:
            NSLog(@"Mail sent failure: %@", [error localizedDescription]);
            break;
        default:
            break;
    }
    selectedRef = nil;
    
    
    // Close the Mail Interface
    [self dismissViewControllerAnimated:YES completion:NULL];
}


#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    // Return the number of rows in the section.
    return [_currentProject.references count];
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    Reference *currentRef = [refArray objectAtIndex:indexPath.row];
    
    
    ReferencesTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"projectCell" forIndexPath:indexPath];
    cell.projectTextField.text = currentRef.referenceType;
    
    for (NSDictionary *dict in referenceTypeArray)
    {
        if ([[dict objectForKey:@"name"] isEqualToString:currentRef.referenceType])
        {
            cell.typeImageView.image = [dict objectForKey:@"imgValue"];
            cell.typeImageView.backgroundColor =  UIColorFromRGB([[dict objectForKey:@"colorValue"] intValue]);
            cell.referenceLabel.attributedText = [currentRef getReferenceString];
            
        }
        
    }
    
    
    cell.delegate = self;
    
    return cell;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 82;
}

-(void)deleteButtonPressedAtCell:(ProjectTableViewCell *)cell
{
    if ([_currentProject.onlineProject boolValue] == TRUE)
    {
        loadingView = [[LoadingView alloc] initWithFrame:self.view.bounds];
        [self.view.window addSubview:loadingView];
        [loadingView fadeIn];

        
        NSIndexPath *indexPath = [self.tableView indexPathForCell:cell];
        selectedRef = [refArray objectAtIndex:indexPath.row];
        selectedIndexPath = indexPath;
        
        [[ReferencingApp sharedInstance] deleteReferenceWithID:selectedRef.referenceID];
        return;
    }
    
    NSIndexPath *indexPath = [self.tableView indexPathForCell:cell];
    
    [self deleteReference:[refArray objectAtIndex:indexPath.row]];
    
    refArray =  [[_currentProject.references allObjects] sortedArrayUsingComparator:^NSComparisonResult(Reference *p1, Reference *p2){
        
        return [[[p1 getReferenceString] string] compare:[[p2 getReferenceString] string] options:NSCaseInsensitiveSearch range:NSMakeRange(0, 1)];
        
    }];

    [self.tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationLeft];

}

-(void)exportButtonPressedAtCell:(ProjectTableViewCell *)cell
{
    NSIndexPath *indexPath = [self.tableView indexPathForCell:cell];
    
    selectedRef = [refArray objectAtIndex:indexPath.row];
    
    NSMutableAttributedString *mailString = [[NSMutableAttributedString alloc] initWithString:@""];
    [mailString appendAttributedString:[selectedRef getReferenceString]];
    
        
    
    
    MFMailComposeViewController *mc = [[MFMailComposeViewController alloc] init];
    
    if ([ReferencingApp sharedInstance].user.isLoggedIn == true)
        [mc setToRecipients:[NSArray arrayWithObject:[ReferencingApp sharedInstance].user.email]];
    
    mc.mailComposeDelegate = self;
    [mc setSubject:[NSString stringWithFormat:@"Reference"]];
    [mc setMessageBody:[mailString mn_HTMLRepresentation] isHTML:YES];
    [self presentViewController:mc animated:YES completion:NULL];
    
    
    
}



-(void)editButtonPressedAtCell:(ProjectTableViewCell *)cell
{
    if ([_currentProject.onlineProject boolValue] == TRUE)
    {
        
        NSIndexPath *indexPath = [self.tableView indexPathForCell:cell];
        selectedRef = [refArray objectAtIndex:indexPath.row];
        selectedIndexPath = indexPath;

        NSMutableArray *projects = [[NSMutableArray alloc] init];
        
        for (Project *project in [ReferencingApp sharedInstance].onlineProjectsArray)
        {
           
            [projects addObject:project.name];
        }
        
        
        
        [ActionSheetStringPicker showPickerWithTitle:@"Select a Project"
                                                rows:projects
                                    initialSelection:0
                                           doneBlock:^(ActionSheetStringPicker *picker, NSInteger selectedIndex, id selectedValue) {
                                               
                                               
                                               selectedOnlineProject = [[ReferencingApp sharedInstance].onlineProjectsArray objectAtIndex:selectedIndex];
                                               if (selectedOnlineProject.name == _currentProject.name)
                                                   return;
                                               
                                               loadingView = [[LoadingView alloc] initWithFrame:self.view.bounds];
                                               [self.view.window addSubview:loadingView];
                                               [loadingView fadeIn];

                                               [[ReferencingApp sharedInstance] switchReferenceWithID:selectedRef.referenceID andType:selectedRef.referenceType toProject:selectedOnlineProject.projectID];
                                               
                                           }
                                         cancelBlock:^(ActionSheetStringPicker *picker) {
                                             NSLog(@"Block Picker Canceled");
                                         }
                                              origin:self.view];
    }
    else
    {
        
        NSIndexPath *indexPath = [self.tableView indexPathForCell:cell];
        selectedRef = [refArray objectAtIndex:indexPath.row];

        
        NSMutableArray *projects = [[NSMutableArray alloc] init];
        NSArray *projectArray = [[ReferencingApp sharedInstance] getDataBaseWithName:@"Project"];
        
        for (Project *project in projectArray)
        {
            [projects addObject:project.name];
        }
        
        [ActionSheetStringPicker showPickerWithTitle:@"Select a Project"
                                                rows:projects
                                    initialSelection:0
                                           doneBlock:^(ActionSheetStringPicker *picker, NSInteger selectedIndex, id selectedValue) {

                                               Project *selectedProj = [projectArray objectAtIndex:selectedIndex];
                                               if (selectedProj.name == _currentProject.name)
                                                   return;

                                               [_currentProject removeReferencesObject:selectedRef];
                                               [selectedProj addReferencesObject:selectedRef];
                                               
                                               AppDelegate* appDelegate = [UIApplication sharedApplication].delegate;
                                               [appDelegate saveContext];
                                               
                                               refArray =  [[_currentProject.references allObjects] sortedArrayUsingComparator:^NSComparisonResult(Reference *p1, Reference *p2){
                                                   
                                                   return [[[p1 getReferenceString] string] compare:[[p2 getReferenceString] string] options:NSCaseInsensitiveSearch range:NSMakeRange(0, 1)];
                                                   
                                               }];
                                               [self.tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationLeft];
                                               
                                           }
                                         cancelBlock:^(ActionSheetStringPicker *picker) {
                                             NSLog(@"Block Picker Canceled");
                                         }
                                              origin:self.view];

        
    }
    
}


-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    if ([segue.identifier isEqualToString:@"typeSelectSegue"])
    {
        EasyReferencingViewController *vc = segue.destinationViewController;
        vc.currentProject = _currentProject;
        vc.title = @"Type select";
        
    }
    if ([segue.identifier isEqualToString:@"referenceDetailSegue"])
    {
        CreateReferenceTableViewController *vc = segue.destinationViewController;
        vc.title = selectedRef.referenceType;
        vc.currentProject = _currentProject;
        vc.currentReference = selectedRef;

        for (NSDictionary *dict in referenceTypeArray)
        {
            if ([[dict objectForKey:@"name"] isEqualToString:selectedRef.referenceType])
            {
                vc.view.tintColor = UIColorFromRGB([[dict objectForKey:@"colorValue"] intValue]);
            }
            
        }
        
        
    }
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    selectedRef = [refArray objectAtIndex:indexPath.row];
    selectedIndexPath = indexPath;
    [self performSegueWithIdentifier:@"referenceDetailSegue" sender:self];
}

-(void)deleteReference:(Reference *)reference
{
    [_currentProject removeReferencesObject:reference];
    AppDelegate* appDelegate = [UIApplication sharedApplication].delegate;
    NSManagedObjectContext *managedObjectContext = appDelegate.managedObjectContext;
    [managedObjectContext deleteObject:reference];
    [appDelegate saveContext];
    
}

-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    UIView *footerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 1)];
    [footerView setBackgroundColor:[UIColor clearColor]];
    
    UIImageView *footerImage = [[UIImageView alloc] initWithFrame:footerView.bounds];
    [footerImage setImage:[UIImage imageNamed:@"project_separator.png"]];
    [footerView addSubview:footerImage];
    
    return footerView;
}

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 1;
}


#pragma mark REFERENCING APP NETWORK DELEGATE

-(void)switchSuccessfull
{
    [_currentProject removeReferencesObject:selectedRef];
    [selectedOnlineProject addReferencesObject:selectedRef];
    selectedRef = nil;
    
    [self.tableView deleteRowsAtIndexPaths:@[selectedIndexPath] withRowAnimation:UITableViewRowAnimationLeft];
    
    refArray =  [[_currentProject.references allObjects] sortedArrayUsingComparator:^NSComparisonResult(Reference *p1, Reference *p2){
        
        return [[[p1 getReferenceString] string] compare:[[p2 getReferenceString] string] options:NSCaseInsensitiveSearch range:NSMakeRange(0, 1)];
        
    }];

    
    [self.tableView reloadData];
    
    selectedIndexPath = nil;
    
    [self unloadLoadingView];

    
}

-(void)switchFailedWithError:(NSString *)errorString
{
    [self unloadLoadingView];
    
    UIAlertView *alert = [[UIAlertView alloc]initWithTitle: @"Error"
                                                   message: errorString
                                                  delegate: self
                                         cancelButtonTitle:@"OK"
                                         otherButtonTitles:nil];
    [alert show];
}

-(void)referenceSucessfullyDeleted
{
    [_currentProject removeReferencesObject:selectedRef];
    selectedRef = nil;
    
    [self.tableView deleteRowsAtIndexPaths:@[selectedIndexPath] withRowAnimation:UITableViewRowAnimationLeft];
    
    refArray =  [[_currentProject.references allObjects] sortedArrayUsingComparator:^NSComparisonResult(Reference *p1, Reference *p2){
        
        return [[[p1 getReferenceString] string] compare:[[p2 getReferenceString] string] options:NSCaseInsensitiveSearch range:NSMakeRange(0, 1)];
        
    }];

    [self.tableView reloadData];
    
    selectedIndexPath = nil;
    
    [self unloadLoadingView];

}

-(void)referenceDeletionFailedWithError:(NSString *)errorString
{
    [self unloadLoadingView];
    
    UIAlertView *alert = [[UIAlertView alloc]initWithTitle: @"Error"
                                                   message: errorString
                                                  delegate: self
                                         cancelButtonTitle:@"OK"
                                         otherButtonTitles:nil];
    [alert show];

}


-(void)unloadLoadingView
{
    
    [UIView animateWithDuration:0.5f animations:^{
        loadingView.alpha = 0.0f;
    } completion:^(BOOL finished) {
        [loadingView removeFromSuperview];
        loadingView = nil;
        
    }];
}




- (IBAction)addButtonPressed:(id)sender {
}
@end
