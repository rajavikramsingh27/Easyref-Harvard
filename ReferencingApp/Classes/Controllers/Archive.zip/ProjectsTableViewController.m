//
//  ProjecsTableViewController.m
//  ReferencingApp
//
//  Created by Radu Mihaiu on 14/08/2014.
//  Copyright (c) 2014 SquaredDimesions. All rights reserved.
//

#import "ProjectsTableViewController.h"
#import "AppDelegate.h"
#import "ProjectReferencesTableViewController.h"
#import "IndexViewController.h"
#import "SettingsTableViewController.h"
#import "NSAttributedString+Ashton.h"



@interface ProjectsTableViewController ()

@end

@implementation ProjectsTableViewController

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        // Custom initialization
    }
    return self;
}



- (void)viewDidLoad
{
    [super viewDidLoad];
    [self.tableView setContentInset:UIEdgeInsetsMake(-1, 0, 0, 0)];

    projectsArray = [[ReferencingApp sharedInstance]  getDataBaseWithName:@"Project"];
    

    newCell = false;
    
    [_createLabel setFont:[UIFont fontWithName:@"MuseoSlab-500" size:18.0f]];
    [_projectButton.titleLabel setFont:[UIFont fontWithName:@"MuseoSlab-500" size:18.0f]];

    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
    
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
    

}



-(void)hideNavBar
{
    [self.tableView setContentInset:UIEdgeInsetsMake(43, 0, 0, 0)];
    [self.navigationController setNavigationBarHidden:YES animated:NO];

}

-(void)showNavBar
{
    [self.tableView setContentInset:UIEdgeInsetsMake(19, 0, 0, 0)];
    [self.navigationController setNavigationBarHidden:NO animated:NO];

}



- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)viewDidAppear:(BOOL)animated
{
    if(_openProjectCreation == TRUE && [ReferencingApp sharedInstance].isOffline == FALSE  && _secondLevel != TRUE)
    {
        _openProjectCreation = false;
        ProjectsTableViewController *vc = [self.storyboard instantiateViewControllerWithIdentifier:@"projectsVC"];
        vc.openProjectCreation = TRUE;
        vc.secondLevel = TRUE;
        vc.showingOnlineProjects = TRUE;
        
        [self.navigationController pushViewController:vc animated:TRUE];
        
    }
    else if (_openProjectCreation == TRUE && [ReferencingApp sharedInstance].isOffline == FALSE  && _secondLevel != TRUE)
    {
        _openProjectCreation = false;
        [self newProjectButtonPressed:nil];

    }
    else if (_openProjectCreation == TRUE)
    {
        _openProjectCreation = false;
        [self newProjectButtonPressed:nil];
    }
    

}

-(void)viewWillAppear:(BOOL)animated
{
    [self setTabBarVisible:true animated:true];

    projectsArray = [[ReferencingApp sharedInstance]  getDataBaseWithName:@"Project"];
    [ReferencingApp sharedInstance].delegate = self;
    [self.tableView reloadData];
    [[IndexViewController sharedIndexVC] showTopMenuWithString:@"Projects"];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(hideNavBar) name:@"hideNavBar" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(showNavBar) name:@"showNavBar" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(showSettings) name:@"showSettings" object:nil];


    self.navigationController.navigationBar.barTintColor = [UIColor colorWithRed:52.0f/255.0f green:152.0f/255.0f blue:219.0f/255.0f alpha:0.70f];
    self.navigationController.navigationBar.backgroundColor = [UIColor colorWithRed:52.0f/255.0f green:152.0f/255.0f blue:219.0f/255.0f alpha:0.50f];

    if ([ReferencingApp sharedInstance].isOffline == FALSE && _secondLevel != TRUE)
    {
        self.navigationItem.rightBarButtonItem = nil;
        self.tableView.tableHeaderView = nil;
    }
    
    if ([ReferencingApp sharedInstance].isOffline == TRUE)
    {
        if ([projectsArray count] > 1)
            self.tableView.tableHeaderView = nil;
    }
    else if ([ReferencingApp sharedInstance].isOffline == FALSE && _secondLevel == TRUE)
    {
        if (_showingOnlineProjects == TRUE)
        {
            if ([[ReferencingApp sharedInstance].onlineProjectsArray count] > 1)
                self.tableView.tableHeaderView = nil;
        }
        else
        {
            if ([projectsArray count] > 1)
                self.tableView.tableHeaderView = nil;
            
        }
    }

    
    if (_secondLevel == TRUE)
    {
        [[IndexViewController sharedIndexVC] hideTopMenu];
    }
    else
    {
        [[IndexViewController sharedIndexVC] showTopMenuWithString:@"Projects"];
    }

}


- (void)setTabBarVisible:(BOOL)visible animated:(BOOL)animated {
    
    // bail if the current state matches the desired state
    if ([self tabBarIsVisible] == visible) return;
    
    // get a frame calculation ready
    CGRect frame = self.tabBarController.tabBar.frame;
    CGFloat height = frame.size.height;
    CGFloat offsetY = (visible)? -height : height;
    
    // zero duration means no animation
    CGFloat duration = (animated)? 0.3 : 0.0;
    
    [UIView animateWithDuration:duration animations:^{
        self.tabBarController.tabBar.frame = CGRectOffset(frame, 0, offsetY);
    }];
}

// know the current state
- (BOOL)tabBarIsVisible {
    return self.tabBarController.tabBar.frame.origin.y < CGRectGetMaxY(self.view.frame);
}

-(void)viewWillDisappear:(BOOL)animated
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    if ([segue.identifier isEqualToString:@"referencesSegue"])
    {
        ProjectReferencesTableViewController *vc  = segue.destinationViewController;
        vc.title = selectedProject.name;
        vc.currentProject = selectedProject;
        
    }
}

-(void)showSettings
{
    
    [self performSelector:@selector(goToSettings) withObject:nil afterDelay:0.3f];
    
}

-(void)goToSettings
{
    
    [self showNavBar];
    SettingsTableViewController *vc = [self.storyboard instantiateViewControllerWithIdentifier:@"settingsVC"];
    [self.navigationController pushViewController:vc animated:TRUE];
    
}


#pragma mark - Table view data source


-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    UIView *footerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 1)];
    [footerView setBackgroundColor:[UIColor clearColor]];
    
    UIImageView *footerImage = [[UIImageView alloc] initWithFrame:footerView.bounds];
    [footerImage setImage:[UIImage imageNamed:@"project_separator.png"]];
    [footerView addSubview:footerImage];
    
    return footerView;
}

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 1;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{

    if (_secondLevel == TRUE)
    {
        if (_showingOnlineProjects == TRUE)
            return [[ReferencingApp sharedInstance].onlineProjectsArray count];
        else
            return  [projectsArray count];

    }
    
    if( [ReferencingApp sharedInstance].isOffline == FALSE)
       return 2;
   
    // Return the number of rows in the section.
    return  [projectsArray count];
}




- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (_secondLevel == TRUE && _showingOnlineProjects == TRUE)
    {
        ProjectTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"projectCell" forIndexPath:indexPath];
        
        if (newCell == false)
        {
            Project *project = [[ReferencingApp sharedInstance].onlineProjectsArray objectAtIndex:indexPath.row];
            
            cell.projectTextField.text = project.name;
            cell.numberLabel.text = [NSString stringWithFormat:@"%i",[project.references count]];
        }
        else
        {
            cell.projectTextField.text = @"";
            cell.numberLabel.text = @"0";
            [cell goToEditMode];
            editingCell = cell;
        }
        
        cell.delegate = self;
        return cell;

    }
    else if( [ReferencingApp sharedInstance].isOffline == FALSE && _secondLevel != TRUE)
    {
        ProjectTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"projectCell" forIndexPath:indexPath];
        [cell.coverView removeGestureRecognizer:cell.panGesture];
        if (indexPath.row == 0)
        {
            cell.projectTextField.text = [ReferencingApp sharedInstance].user.name;
            cell.numberLabel.text = [NSString stringWithFormat:@"%i",[[ReferencingApp sharedInstance].onlineProjectsArray count]];
            

        }
        else
        {
            cell.projectTextField.text = @"Local";
            cell.numberLabel.text = [NSString stringWithFormat:@"%i",[projectsArray count]];

        }
        
        return cell;

    }
    
    ProjectTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"projectCell" forIndexPath:indexPath];
    
    if (newCell == false)
    {
        Project *project = [projectsArray objectAtIndex:indexPath.row];

        cell.projectTextField.text = project.name;
        cell.numberLabel.text = [NSString stringWithFormat:@"%i",[project.references count]]; 
    }
    else
    {
        cell.projectTextField.text = @"";
        cell.numberLabel.text = @"0";
        [cell goToEditMode];
        editingCell = cell;
    }
    
    cell.delegate = self;
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (editingCell != nil)
        return;
    
    if( [ReferencingApp sharedInstance].isOffline == FALSE && _secondLevel != TRUE)
    {
        ProjectsTableViewController *vc = [self.storyboard instantiateViewControllerWithIdentifier:@"projectsVC"];
        vc.secondLevel = TRUE;
        
        if (indexPath.row == 0)
            vc.showingOnlineProjects = TRUE;
        else
            vc.showingOnlineProjects = FALSE;
        
        [self.navigationController pushViewController:vc animated:TRUE];
    }
    else
    {
        
        if (_secondLevel == TRUE && _showingOnlineProjects == TRUE)
            selectedProject = [[ReferencingApp sharedInstance].onlineProjectsArray objectAtIndex:indexPath.row];
        else
            selectedProject = [projectsArray objectAtIndex:indexPath.row];
        
        [self performSegueWithIdentifier:@"referencesSegue" sender:self];

    }
}


- (IBAction)addButtonPressed:(id)sender
{
    
    [[IndexViewController sharedIndexVC] hideTopMenu];

    AppDelegate* appDelegate = [UIApplication sharedApplication].delegate;
    NSManagedObjectContext *managedObjectContext = appDelegate.managedObjectContext;

    
    if (_secondLevel == TRUE && _showingOnlineProjects == TRUE)
    {
     
        NSEntityDescription *entity = [NSEntityDescription entityForName:@"Project" inManagedObjectContext:managedObjectContext];
        Project *newProject = [[Project alloc] initWithEntity:entity insertIntoManagedObjectContext:nil];
        newProject.onlineProject = [NSNumber numberWithBool:TRUE];
        [[ReferencingApp sharedInstance].onlineProjectsArray insertObject:newProject atIndex:0];
        selectedProject = newProject;

    }
    else
    {
        
        Project *newProject = [NSEntityDescription insertNewObjectForEntityForName:@"Project" inManagedObjectContext:managedObjectContext];
        newProject.onlineProject = [NSNumber numberWithBool:FALSE];
        newProject.dateCreated = [NSDate date];
        selectedProject = newProject;
        
        projectsArray = [[ReferencingApp sharedInstance]  getDataBaseWithName:@"Project"];
        
    }


    newCell = true;
    [self.tableView insertRowsAtIndexPaths:@[[NSIndexPath indexPathForRow:0 inSection:0]] withRowAnimation:UITableViewRowAnimationTop];

}

- (IBAction)newProjectButtonPressed:(id)sender
{
    self.tableView.tableHeaderView = nil;
    [self addButtonPressed:nil];
}


-(void)unloadLoadingView
{
    
    [UIView animateWithDuration:0.5f animations:^{
        loadingView.alpha = 0.0f;
    } completion:^(BOOL finished) {
        [loadingView removeFromSuperview];
        loadingView = nil;

    }];
}

#pragma mark REFERECING APP NETWORK DELEGATE

-(void)projectEditingFailedWithError:(NSString *)errorString
{
    
    [self unloadLoadingView];
    
    
    UIAlertView *alert = [[UIAlertView alloc]initWithTitle: @"Error"
                                                   message: errorString
                                                  delegate: self
                                         cancelButtonTitle:@"OK"
                                         otherButtonTitles:nil];
    [alert show];

}

-(void)projectScuessfullyEdited
{
    
    NSLog(@"name before - %@",selectedProject.name);
    
    selectedProject.name = editingCell.projectTextField.text;
    
    NSLog(@"name after - %@",selectedProject.name);

    selectedProject = nil;
    editingCell = nil;
    newCell = false;
    
    
    
    [self.navigationItem setLeftBarButtonItem:nil animated:TRUE];
    [self.navigationItem setRightBarButtonItem:[[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAdd target:self action:@selector(addButtonPressed:)] animated:TRUE];

    
    [self unloadLoadingView];
}

-(void)projectDeletionFailedWithError:(NSString *)errorString
{
    [self unloadLoadingView];
    
    
    UIAlertView *alert = [[UIAlertView alloc]initWithTitle: @"Error"
                                                   message: errorString
                                                  delegate: self
                                         cancelButtonTitle:@"OK"
                                         otherButtonTitles:nil];
    [alert show];

}

-(void)projectSucessfullyDeleted
{
    [[ReferencingApp sharedInstance].onlineProjectsArray removeObject:selectedProject];
    selectedProject = nil;
    
    [self.tableView deleteRowsAtIndexPaths:@[deleteIndexPath] withRowAnimation:UITableViewRowAnimationLeft];
    deleteIndexPath = nil;

    [self unloadLoadingView];
    
}

-(void)projectCreationFailedWithError:(NSString *)errorString
{
    [self unloadLoadingView];
    
    
    UIAlertView *alert = [[UIAlertView alloc]initWithTitle: @"Error"
                                                   message: errorString
                                                  delegate: self
                                         cancelButtonTitle:@"OK"
                                         otherButtonTitles:nil];
    [alert show];
    
}

-(void)projectSucessfullyCreatedWithData:(NSDictionary *)dictionary
{
    selectedProject.projectID = [[dictionary objectForKey:@"id"] stringValue];
    selectedProject.name = [dictionary objectForKey:@"name"];
    
    
    [editingCell endEditing];
    [self unloadLoadingView];
    
}


#pragma mark SLIDEABLE CELL DELEGATE METHODS

-(BOOL)canSlide
{
    if (editingCell != nil)
        return NO;
    else
        return YES;
}

-(void)deleteButtonPressedAtCell:(ProjectTableViewCell *)cell
{
    if (_secondLevel == TRUE && _showingOnlineProjects == TRUE)
    {
        if (newCell == TRUE)
        {
            newCell = false;
            
            NSIndexPath *indexPath = [self.tableView indexPathForCell:cell];
            [[ReferencingApp sharedInstance].onlineProjectsArray removeObjectAtIndex:indexPath.row];
            selectedProject = nil;
            
            [self.tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationLeft];
            deleteIndexPath = nil;
            
            [self unloadLoadingView];
            
            [self.navigationItem setLeftBarButtonItem:nil animated:TRUE];
            [self.navigationItem setRightBarButtonItem:[[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAdd target:self action:@selector(addButtonPressed:)] animated:TRUE];

            return;
        }
        
        NSIndexPath *indexPath = [self.tableView indexPathForCell:cell];
        deleteIndexPath = indexPath;
        
        Project *proj = [[[ReferencingApp sharedInstance] onlineProjectsArray] objectAtIndex:indexPath.row];
        selectedProject = proj;
        
        [[ReferencingApp sharedInstance] deleteProjectWithID:proj.projectID];
        loadingView = [[LoadingView alloc] initWithFrame:self.view.bounds];
        [self.view.window addSubview:loadingView];
        [loadingView fadeIn];

        return;
    }
    
    
    NSIndexPath *indexPath = [self.tableView indexPathForCell:cell];
    
    [self deleteProject:[projectsArray objectAtIndex:indexPath.row]];
    projectsArray = [[ReferencingApp sharedInstance]  getDataBaseWithName:@"Project"];

    
    [self.tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationLeft];
}


-(void)exportButtonPressedAtCell:(ProjectTableViewCell *)cell
{
    
    [[IndexViewController sharedIndexVC] hideTopMenu];
    
    NSIndexPath *indexPath = [self.tableView indexPathForCell:cell];
    
    if (_secondLevel == TRUE && _showingOnlineProjects == TRUE)
        selectedProject = [[ReferencingApp sharedInstance].onlineProjectsArray objectAtIndex:indexPath.row];
    else
        selectedProject = [projectsArray objectAtIndex:indexPath.row];
    
    
    NSMutableAttributedString *mailString = [[NSMutableAttributedString alloc] initWithString:@""];
    
    for (Reference *ref in selectedProject.references)
    {
        [mailString appendAttributedString:[ref getReferenceString]];
        [mailString appendAttributedString:[[NSAttributedString alloc] initWithString:@"\n\n"]];


    }
    
    MFMailComposeViewController *mc = [[MFMailComposeViewController alloc] init];
    
    if ([ReferencingApp sharedInstance].user.isLoggedIn == true)
        [mc setToRecipients:[NSArray arrayWithObject:[ReferencingApp sharedInstance].user.email]];
    
    mc.mailComposeDelegate = self;
    [mc setMessageBody:[mailString mn_HTMLRepresentation] isHTML:YES];
    [mc setSubject:[NSString stringWithFormat:@"%@ References",selectedProject.name]];
    [self presentViewController:mc animated:YES completion:NULL];

    
    
}

- (void) mailComposeController:(MFMailComposeViewController *)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError *)error
{
    switch (result)
    {
        case MFMailComposeResultCancelled:
            NSLog(@"Mail cancelled");
            break;
        case MFMailComposeResultSaved:
            NSLog(@"Mail saved");
            break;
        case MFMailComposeResultSent:
            NSLog(@"Mail sent");
            break;
        case MFMailComposeResultFailed:
            NSLog(@"Mail sent failure: %@", [error localizedDescription]);
            break;
        default:
            break;
            
    }
    
    selectedProject = nil;
    // Close the Mail Interface
    [self dismissViewControllerAnimated:YES completion:NULL];
}

-(void)editButtonPressedAtCell:(ProjectTableViewCell *)cell
{
    [[IndexViewController sharedIndexVC] hideTopMenu];

    NSIndexPath *indexPath = [self.tableView indexPathForCell:cell];
    preEditString = cell.projectTextField.text;
    editingCell = cell;
    
    if (_secondLevel == TRUE && _showingOnlineProjects == TRUE)
        selectedProject = [[ReferencingApp sharedInstance].onlineProjectsArray objectAtIndex:indexPath.row];
    else
        selectedProject = [projectsArray objectAtIndex:indexPath.row];
    
    [self addEditingNavItem];
}


-(void)editingFinishedAtCell:(ProjectTableViewCell *)cell
{
    
    
    if ([editingCell.projectTextField.text isEqualToString:@""] || [editingCell.projectTextField.text isEqualToString:@"Uncategorized"])
    {
        [editingCell shake];
        return;
    }
    
    if (_secondLevel == TRUE && _showingOnlineProjects == TRUE && newCell == false)
    {
        if (dontCallEditing == TRUE)
        {
            dontCallEditing = false;
            [self.navigationItem setLeftBarButtonItem:nil animated:TRUE];
            [self.navigationItem setRightBarButtonItem:[[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAdd target:self action:@selector(addButtonPressed:)] animated:TRUE];
            return;
        }
        
        if ([preEditString isEqualToString:editingCell.projectTextField.text])
        {
            [self.navigationItem setLeftBarButtonItem:nil animated:TRUE];
            [self.navigationItem setRightBarButtonItem:[[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAdd target:self action:@selector(addButtonPressed:)] animated:TRUE];
            selectedProject = nil;
            editingCell = nil;
            newCell = false;

            return;
        }
        
        
        [[ReferencingApp sharedInstance] editProjectWithID:selectedProject.projectID andNewName:editingCell.projectTextField.text];
        loadingView = [[LoadingView alloc] initWithFrame:self.view.bounds];
        [self.view.window addSubview:loadingView];
        [loadingView fadeIn];

        return;
    }
    
    selectedProject.name = editingCell.projectTextField.text;
    AppDelegate* appDelegate = [UIApplication sharedApplication].delegate;
    [appDelegate saveContext];
   
    selectedProject = nil;
    editingCell = nil;
    newCell = false;
    
    if ( _secondLevel != TRUE)
        [[IndexViewController sharedIndexVC] showTopMenuWithString:@"Projects"];


    [self.navigationItem setLeftBarButtonItem:nil animated:TRUE];
    [self.navigationItem setRightBarButtonItem:[[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAdd target:self action:@selector(addButtonPressed:)] animated:TRUE];

}

-(void)addEditingNavItem
{
    [self.navigationItem setLeftBarButtonItem:[[UIBarButtonItem alloc] initWithTitle:@"Cancel" style:UIBarButtonItemStylePlain target:self action:@selector(cancelPressed)] animated:true];
    [self.navigationItem setRightBarButtonItem:[[UIBarButtonItem alloc] initWithTitle:@"Done" style:UIBarButtonItemStyleDone target:self action:@selector(donePressed)] animated:TRUE];

}


-(void)cancelPressed
{
    if (newCell == TRUE)
    {
        
        if(_secondLevel == TRUE && _showingOnlineProjects == TRUE)
        {
            [editingCell.projectTextField resignFirstResponder];
            
            [self deleteButtonPressedAtCell:editingCell];

            editingCell = nil;
            
            return;
        }
        
        
        projectsArray = [[ReferencingApp sharedInstance]  getDataBaseWithName:@"Project"];

        [editingCell.projectTextField resignFirstResponder];
        newCell = false;
        [self deleteButtonPressedAtCell:editingCell];
        editingCell = nil;
        
        [self.navigationItem setLeftBarButtonItem:nil animated:TRUE];
        [self.navigationItem setRightBarButtonItem:[[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAdd target:self action:@selector(addButtonPressed:)] animated:TRUE];
        
        if ( _secondLevel != TRUE)
            [[IndexViewController sharedIndexVC] showTopMenuWithString:@"Projects"];

        return;
    }
    else
    {
        if(_secondLevel == TRUE && _showingOnlineProjects == TRUE)
            dontCallEditing = TRUE;

        editingCell.projectTextField.text = preEditString;
        [editingCell endEditing];

    }
    
    editingCell = nil;

    
}

-(void)donePressed
{
    self.tableView.userInteractionEnabled = true;
    if ([editingCell.projectTextField.text isEqualToString:@""] || [editingCell.projectTextField.text isEqualToString:@"Uncategorized"])
    {
        [editingCell shake];
        return;
    }
    
    if (_secondLevel == TRUE && _showingOnlineProjects == TRUE && newCell == TRUE)
    {
        [[ReferencingApp sharedInstance] createProjectWithName:editingCell.projectTextField.text];
        
        loadingView = [[LoadingView alloc] initWithFrame:self.view.bounds];
        [self.view.window addSubview:loadingView];
        [loadingView fadeIn];

        return;
    }
    
    [editingCell endEditing];

}


-(void)deleteProject:(Project *)project
{
    AppDelegate* appDelegate = [UIApplication sharedApplication].delegate;
    NSManagedObjectContext *managedObjectContext = appDelegate.managedObjectContext;
    [managedObjectContext deleteObject:project];
    [appDelegate saveContext];

}





@end
